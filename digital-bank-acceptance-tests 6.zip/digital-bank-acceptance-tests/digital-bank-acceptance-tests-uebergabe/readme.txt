Version 1.0.0
=============
* Initiale Implementierung


Neue Queues
===========
-


Neue Channels
=============
-


Neue ODBC Konfiguration
=======================
-


Neue Configurable Service
=========================
-


Neue JNDI Eintr�ge
==================
Connection Factories
--------------------
-


Queues
------
-


Neue Node Konfigurationen
=========================
-
